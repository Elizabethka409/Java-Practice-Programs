// exception class to handle incorrect age entered by user
public class AgeException extends Exception {

// no-arg constructor (default)
   public AgeException() {
      super("Invalid age entered.");
   }

// overloaded constructor
   public AgeException(String message) {
      super(message);
   }
}