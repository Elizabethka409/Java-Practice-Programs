import java.util.Scanner;
import java.util.ArrayList;

/*
* Ka258Exam
*
* Summary: This project folder demonstrates the system of a savings program
* for youth between ages of 5 to 17 years old for
* G-Rated and PG-Rated Movies.
* 
* To enroll, users need to submit their name and age.
* Based on their age entered, the user will be eligible for 
* the following savings:
*     Ages 5-12 - $5.00 off of a G-Rated Movie
*     Ages 13-17 - $4.00 off of a PG Rated Movie
*/

public class MovieSavingsDriver {
   
   /*
   This static method named validAge checks to see if the entered age is valid.
   (note: variable is named ageStr because it is specifically a String
   and not int as may inferred.)
   */
   public static String validAge(String ageStr) throws AgeException {
      if(ageStr.length() < 1 || ageStr.length() > 2) {
         throw new AgeException("Age must be 1 or 2 digits.");
      }
      
      int age;
      
      // try and catch block used for errors and exceptions in age validation process
      try {
      // age transformed into an int to perform the exception checks appropriately.
         age = Integer.parseInt(ageStr);
      }
      catch (NumberFormatException e) {
         throw new AgeException("Age must be a number.");
      }
      
      // additional error type message if applicable
      if (age < 5 || age > 17) {
            throw new AgeException("You must be between 5 and 17 to be eligible for savings");
      }
      
      return ageStr;
   }
   
   
   // 
   public static void main(String[] args) {
      // creating our respective objects for scanner info 
      // and lists of savings accumulated by the end of program.
      Scanner scanner = new Scanner(System.in);
      ArrayList<GRatedMovieSavings> gMovieList = new ArrayList<>();
      ArrayList<PGRatedMovieSavings> pgMovieList = new ArrayList<>();
      
      String choice;
      
      // do-while loop to allow user to enter multiples persons for savings
      do {
         System.out.print("Enter Name: ");
         String name = scanner.nextLine();
         
         System.out.print("Age: ");
         String ageInput = scanner.nextLine();
         
         /* 
         try and catch block to begin user collection process,
         validate whether they are eligible for either type of savings,
         and saves their instances into the respective lists/arrays.
         
         Throws an exception/error message in catch portion of the block
         if neither type of savings accepts the given age argument.
         */
         try {
            String validAge = validAge(ageInput);
            int ageNum = Integer.parseInt(validAge);
            System.out.println("User is of valid age to get a discount");
         
            if (ageNum >= 5 && ageNum <= 12) {
               GRatedMovieSavings gSaver = new GRatedMovieSavings(name, validAge);
               gMovieList.add(gSaver);
               System.out.println(name + " is eligible for savings on a G-Rated movie");
             } else if (ageNum >= 13 && ageNum <= 17) {
               PGRatedMovieSavings pgSaver = new PGRatedMovieSavings(name, validAge);
               pgMovieList.add(pgSaver);
               System.out.println(name + " is eligible for savings on a PG-Rated movie");
            }
         } catch (AgeException e) {
            System.out.println(e.getMessage());
         }
         
         System.out.print("Would you like to enter another name? (Y/N): ");
         choice = scanner.nextLine();
         System.out.println("");
      
      } while (choice.equalsIgnoreCase("Y")); // ends user collection program
      
      
      // displays all savings (all info in their respective arrays)
      // at the end of program, almost like a receipt.
      System.out.println("\n**********Savings List***********\n");
      
      System.out.println("****G-Movie Savers****");
      for (GRatedMovieSavings g : gMovieList) {
         g.displaySavings();
      }
      
      System.out.println("****PG-Movie Savers****");
      for (PGRatedMovieSavings pg : pgMovieList) {
         pg.displaySavings();
      }
      
      scanner.close();
   }
   
}