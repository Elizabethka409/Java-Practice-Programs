public class PGRatedMovieSavings implements MovieSavings {
   private String name, age;
   
   //no-arg constructor
   public PGRatedMovieSavings() {
     this.name = "";
     this.age = "";
   }
   
   // constructor that accepts arguments/parameters
   public PGRatedMovieSavings(String name, String age) {
     this.name = name;
     this.age = age;
   }
   
   // getter methods
   //@return The Name of user
   public String getName()
   {
      return name;
   }
   
   // @return The Age of user
   public String getAge()
   {
      return age;
   }
   
   // setter methods
   // @param Name of user
   public void setName(String name) {
      this.name = name;
   }
   
   // @param Age of user
   public void setAge(String age) {
      this.age = age;
   }
   
   
   // method that displays the savings respective the PG-rated movies
   public void displaySavings() {
       System.out.println("Name:\t  " + name + "\nAge:\t  " + age + "\nSavings: $4.00 off a PG-Rated Movie\n");
   }
}